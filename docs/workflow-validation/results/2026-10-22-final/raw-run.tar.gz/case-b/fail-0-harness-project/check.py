import sys
from pathlib import Path
print('test gate')
sys.exit(0 if Path('pass.txt').exists() else 1)
